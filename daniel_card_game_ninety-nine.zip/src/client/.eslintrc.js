module.exports = {
  env: {
    node: true,
  }
}
